export const getRandomProfilePicture = (seed) => {
  return `https://avatar.tobi.sh/${seed}.png`
}