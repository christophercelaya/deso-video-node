import { Feed } from '@components/Feed'

export default Feed;