import { Privacy } from '@components/Privacy'

export default Privacy