import { Home } from '@components/Home'

export default Home