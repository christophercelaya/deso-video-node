import { Upload } from "@components/Upload";

export default Upload