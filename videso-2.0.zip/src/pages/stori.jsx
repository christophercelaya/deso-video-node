import { Stori } from '@components/Stori'

export default Stori;