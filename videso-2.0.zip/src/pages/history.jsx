import { History } from "@components/History";

export default History