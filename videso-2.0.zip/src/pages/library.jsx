import { Library } from "@components/Library";

export default Library;