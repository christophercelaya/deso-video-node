import { About } from "@components/About";

export default About