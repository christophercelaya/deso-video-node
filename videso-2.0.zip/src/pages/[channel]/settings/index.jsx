import { Settings } from '@components/Channel/Settings'

export default Settings