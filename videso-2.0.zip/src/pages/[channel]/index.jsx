import { Channel } from '@components/Channel'

export default Channel