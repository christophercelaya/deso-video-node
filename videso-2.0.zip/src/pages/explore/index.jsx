import { Explore } from '@components/Explore'

export default Explore