import { Category } from '@components/Explore/Category'

export default Category